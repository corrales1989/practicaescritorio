﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;
using PracticaEscritorio.Model.ConfiguracionesBD;


//NOTA: ES importante tomar en cuenta que todas las configuraciones de la parte de datos son independientes a las del controlador y vista, este solo se debe indicar si es un SP con parametros o sin parametros
namespace PracticaEscritorio.Controller
{
    class empleadosController
    {
        private AdaptadorDatos _AdaptadorDatos;
        public void guardar(string Nombre_SP, ArrayList Campos_SP, ArrayList Valores_SP)
        {
            _AdaptadorDatos = new AdaptadorDatos();
            _AdaptadorDatos.Seleccionar_SP_parametrizado(Nombre_SP, Campos_SP, Valores_SP);

            /*foreach (string value in list)
            {
                MessageBox.Show(value.ToString());
            }*/

        }
        public void eliminar()
        {


        }
        public void Actualizar()
        {


        }

        internal DataSet consultaPuesto(string Nombre_SP)
        {
            _AdaptadorDatos = new AdaptadorDatos();

            return _AdaptadorDatos.Seleccionar_SP(Nombre_SP);
        }

        internal DataSet getEmpleados(string sp_ConsultaEmpleados)
        {
            _AdaptadorDatos = new AdaptadorDatos();
            return _AdaptadorDatos.Seleccionar_SP(sp_ConsultaEmpleados);
        }

        internal DataSet getEmpleado(string sp_getEmpleado, ArrayList campos, ArrayList valores)
        {
            _AdaptadorDatos = new AdaptadorDatos();
            return _AdaptadorDatos.Seleccionar_SP_parametrizado(sp_getEmpleado, campos, valores);
        }
    }
}
