﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PracticaEscritorio.Controller;
using System.Text.RegularExpressions; 


namespace PracticaEscritorio.View
{

    public partial class Actualizar : Form
    {
        //ATRIBUTOS GENERALES
        private int idEmpleado;
        private empleadosController empleados;
        private string temporalTxtNombre;
        private string temporalTxtApellido;


        //CONTRUCTORES 
        public Actualizar()
        {
            InitializeComponent();
        }
        public Actualizar(int idModificar)
        {
            idEmpleado = idModificar;
            InitializeComponent();
            getEmpleado(idEmpleado);

        }

        //METODOS 


        private void Actualizar_Load(object sender, EventArgs e)
        {
            getEmpleado(idEmpleado);
        }

        private void getEmpleado(int idempleado)
        {
            empleados = new empleadosController();
            ArrayList campos = new ArrayList();
            campos.Add("ID");
            ArrayList valores = new ArrayList();
            valores.Add(idempleado);
            DataSet dataSetEmpleados =empleados.getEmpleado("sp_getEmpleado", campos, valores); //EJECUTA EL BORRADO EN BD CON EL sp_EliminarEmpleado
            txtNombre.Text = dataSetEmpleados.Tables[0].Rows[0].ItemArray[1].ToString();
            txtApellido.Text = dataSetEmpleados.Tables[0].Rows[0].ItemArray[2].ToString();
            txtEdad.Text = dataSetEmpleados.Tables[0].Rows[0].ItemArray[3].ToString();
            //cancelacion de clickderecho
            txtNombre.ContextMenuStrip = new ContextMenuStrip();
            txtApellido.ContextMenuStrip = new ContextMenuStrip();
            txtEdad.ContextMenuStrip = new ContextMenuStrip();
            //llenado de temporales para modificacion
            temporalTxtNombre = txtNombre.Text;
            temporalTxtApellido = txtApellido.Text;

            dateFecha.Text = dataSetEmpleados.Tables[0].Rows[0].ItemArray[6].ToString();

            DataSet ds = empleados.consultaPuesto("SP_cat_roles");
            if (ds.Tables[0].Rows.Count > 0)
            {

                cbPuesto.DataSource = ds.Tables[0].DefaultView;
                cbPuesto.DisplayMember = "descrol"; //MUESTRA LAS DESCRIPCIONES DE LA TABLA
                cbPuesto.ValueMember = "numrol";//OBTIENE LOS ID 


            }
            cbPuesto.Text = dataSetEmpleados.Tables[0].Rows[0].ItemArray[5].ToString();
        }

        


        //validaciones 

        private void txtEdad_TextChanged(object sender, EventArgs e)
        {
            txtNombre.CharacterCasing = CharacterCasing.Upper;
            txtApellido.CharacterCasing = CharacterCasing.Upper;
            txtEdad.CharacterCasing = CharacterCasing.Upper;
        }


        private int validaciones()
        {
            int bandera = 0;
            foreach (Control c in this.Controls) // en vez de this puedes poner el nombre de un panel si es que tus textboxes se encuentran dentro de uno
            {
                if (c is TextBox & c.Text.Trim() == "" )
                {
                  
                    MessageBox.Show("¡Hay campos vacios!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return bandera = 1;
                }
            }
            return bandera;
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (Char.IsNumber(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsControl(e.KeyChar))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("error:" + ex);
            }
        }

        private void txtEdad_KeyUp(object sender, KeyEventArgs e)
        {
            int numeros;

            try
            {
                numeros = int.Parse(txtEdad.Text);
            }
            catch
            {
                txtEdad.Text = "";

            }
        }
        //EN MISMO EVENTO SE INCLUYEN DOS CAMPOS "NOMBRE" Y "APELLIDO"
        private void txtNombre_KeyUp(object sender, KeyEventArgs e)
        {

            if (validacionSoloLetras(txtNombre.Text) == 1)
            {
                txtNombre.Text = "";
            }
            
        }
        private void txtApellido_KeyUp(object sender, KeyEventArgs e)
        {
            if (validacionSoloLetras(txtApellido.Text) == 1)
            {
                txtApellido.Text = "";
            }
        }


        private void txtApellido_KeyPress(object sender, KeyPressEventArgs Tecla)
        {
            
            try
            {
                if (Char.IsLetter(Tecla.KeyChar))
                {
                    Tecla.Handled = false;
                }
                else if (Char.IsControl(Tecla.KeyChar))
                {
                    Tecla.Handled = false;
                }
                else if (Char.IsSeparator(Tecla.KeyChar))
                {
                    Tecla.Handled = false;
                }
                else
                {
                    Tecla.Handled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("error:" + ex);
            }

        }


        //botones

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            if (validaciones() == 0)
            {
                empleados = new empleadosController();
                // Create an ArrayList and add 3 elements.
                ArrayList campos = new ArrayList();
                campos.Add("ID");
                campos.Add("Nombre");
                campos.Add("Apellido");
                campos.Add("Edad");
                campos.Add("Puesto");
                campos.Add("Fecha");


                ArrayList valores = new ArrayList();
                valores.Add(idEmpleado);
                valores.Add(txtNombre.Text.Trim());
                valores.Add(txtApellido.Text.Trim());
                valores.Add(Int32.Parse(txtEdad.Text));
                valores.Add(cbPuesto.SelectedValue);
                valores.Add(dateFecha.Text);
                empleados.guardar("sp_actualizarEmpleado", campos, valores);
                MessageBox.Show("registro exitoso");
                Main ventana1 = Owner as Main;// LA OTRA PARTE DE LA TRANSFERENCIA DE DATOS DE EL FORM ALTA A MAIN 
                ventana1.llenadoGrid(); // LLENA DESPUES DE LA ALTA EL GRID PARA ACTUALIZARLO
                this.Close();
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        //esta validacion se realiza por que con ella se asegura no poder PEGAR numeros con ctrl+V
        private int validacionSoloLetras(string texto)
        {
            bool resultado = Regex.IsMatch(texto, @"^[a-zA-Z]+$");
            if (!resultado)
            {
                //No es una letra del alfabeto, por lo tanto emitir mensaje de error.
               // MessageBox.Show("¡Solo es posible agregar letras!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            return 0;
        }


        private void txtNombre_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
               
                //MessageBox.Show("No se puede utilizar el boton derecho");
            }
            
        }


       

       

       



    }
}
