﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PracticaEscritorio.Controller;

namespace PracticaEscritorio.View
{
    public partial class Main : Form
    {
        //VARIABLES GENERALES 
        private empleadosController empleados = new empleadosController();
        private int rengon;
        private int columna;
        int elementoEliminar;


        public Main()
        {
            InitializeComponent();
        }

        //DATOS QUE SE CARGA AL INICIO AL INVOCAR EL GRID 
        private void Main_Load(object sender, EventArgs e)
        {
            dgvEmpleados.AllowUserToAddRows = false;
            dgvEmpleados.DataSource = empleados.getEmpleados("SP_cat_roles");
            //cargan los datos del grid abonos
            llenadoGrid();
            this.dgvEmpleados.Columns["ID"].Visible = false;
            this.dgvEmpleados.Columns["Puesto"].Visible = false;
            //DataSet ds = empleados.getEmpleados("sp_ConsultaEmpleados");
           
            
        }

        //LLENA EL GRID 
        public void llenadoGrid()
        {
            DataSet ds = empleados.getEmpleados("sp_ConsultaEmpleados");
            if (ds.Tables[0].Rows.Count > 0)
            {
                dgvEmpleados.DataSource = ds.Tables[0].DefaultView;
            }
            
        }


        //METODO PARA REALIZAR SELECCION DE LA FILA Y EL ID PARA BORRAR O PARA MODIFICAR
        private void dgvEmpleados_CellMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            rengon = e.RowIndex;
            columna = e.ColumnIndex;
            elementoEliminar = int.Parse(dgvEmpleados.Rows[rengon].Cells[0].Value.ToString());
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            
        }

        private void dgvEmpleados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int idModificar;
            idModificar = int.Parse(dgvEmpleados.Rows[rengon].Cells[0].Value.ToString());
            Actualizar actualizar = new Actualizar(idModificar);
            AddOwnedForm(actualizar); //EN PARTICULAR ESTA ES LA PARTE 1 PARA QUE PUEDA ENVIAR LOS DATOS EN TIEMPO REAL AL GRID DESDE FORM ALTA 
            actualizar.ShowDialog();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Alta Alta = new Alta();
            AddOwnedForm(Alta); //EN PARTICULAR ESTA ES LA PARTE 1 PARA QUE PUEDA ENVIAR LOS DATOS EN TIEMPO REAL AL GRID DESDE FORM ALTA 
            Alta.ShowDialog();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //VARIABLES LOCALES 
            empleados = new empleadosController();
            ArrayList campos = new ArrayList();
            ArrayList valores = new ArrayList();



            campos.Add("ID");
            valores.Add(elementoEliminar);

            //PREGUNTA PARA BORRAR LA FILA 
            if (MessageBox.Show("¿Estas seguro que desea Eliminar Al Empleado?", "◄ AVISO ►", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Information, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                empleados.guardar("sp_EliminarEmpleado", campos, valores); //EJECUTA EL BORRADO EN BD CON EL sp_EliminarEmpleado 
                dgvEmpleados.Rows.RemoveAt(dgvEmpleados.CurrentRow.Index); //PERMITE BORRADO DE PANTALLA
            }

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            int idModificar;
            idModificar = int.Parse(dgvEmpleados.Rows[rengon].Cells[0].Value.ToString());
            Actualizar actualizar = new Actualizar(idModificar);
            AddOwnedForm(actualizar); //EN PARTICULAR ESTA ES LA PARTE 1 PARA QUE PUEDA ENVIAR LOS DATOS EN TIEMPO REAL AL GRID DESDE FORM ALTA 
            actualizar.ShowDialog();

        }

        private void dgvEmpleados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



    }
}





