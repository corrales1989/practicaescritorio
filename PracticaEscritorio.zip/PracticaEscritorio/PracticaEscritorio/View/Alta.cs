﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using PracticaEscritorio.Controller;
using System.Text.RegularExpressions;

//FORM DE ALTA LLAMADO DESDE FORM MAIN

namespace PracticaEscritorio.View
{
    public partial class Alta : Form
    {
        private empleadosController empleados;
        //variables generales para guardar el registro previo de texbox
        private string campoNombre = string.Empty;
        private string campoApellido = string.Empty;
       

        //contructores **uno parametrizado y otro normal**
        public Alta()
        {
            InitializeComponent();
            
        }

     

        //CARGOS DE DATOS EN COMBOBOX
        private void Alta_Load(object sender, EventArgs e)
        {
            //cancelacion de clickderecho
            txtNombre.ContextMenuStrip = new ContextMenuStrip();
            txtApellido.ContextMenuStrip = new ContextMenuStrip();
            txtEdad.ContextMenuStrip = new ContextMenuStrip();
            empleados = new empleadosController();
            DataSet ds=empleados.consultaPuesto("SP_cat_roles");
            if (ds.Tables[0].Rows.Count > 0)
            {
                cbPuesto.DataSource = ds.Tables[0].DefaultView;
                cbPuesto.DisplayMember = "descrol"; //MUESTRA LAS DESCRIPCIONES DE LA TABLA
                cbPuesto.ValueMember = "numrol";//OBTIENE LOS ID 
                
            }
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

            txtNombre.CharacterCasing = CharacterCasing.Upper;
            txtApellido.CharacterCasing = CharacterCasing.Upper;
            
            
        }


        //validaciones 


        private int validaciones()
        {
            int bandera = 0;
            // en vez de this puedes poner el nombre de un panel si es que tus textboxes se encuentran dentro de uno
            foreach (Control c in this.Controls) 
            {
                if (c is TextBox & c.Text.Trim() == "")
                {

                    MessageBox.Show("¡Hay campos vacios!", "Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return bandera = 1;
                }


            }
            return bandera;
        }
        public void SoloNumeros(KeyPressEventArgs Tecla)
        {
            
            try
            {
                if (Char.IsNumber(Tecla.KeyChar))
                {
                    Tecla.Handled = false;
                }
                else if (Char.IsControl(Tecla.KeyChar))
                {
                    Tecla.Handled = false;
                }
                else
                {
                    Tecla.Handled = true;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("error:" + ex);
            }
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            
            try
            {
                if (Char.IsNumber(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsControl(e.KeyChar))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
                
                

            }
            catch (Exception ex)
            {

                MessageBox.Show("error:" + ex);
            }

        }

        private void txtEdad_KeyUp(object sender, KeyEventArgs e)
        {
            int numeros;
           
            try
            {
                numeros = int.Parse(txtEdad.Text);
            }
            catch
            {
                    txtEdad.Text = "";
                
            }

        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            //carga las variables generales para sustituir valores en caso de ingresar algun dato erroneo
            campoNombre = txtNombre.Text.ToString();
            //variable local para evaluar los espacios
            string cadena = txtNombre.Text.ToString();
            
            try
            {
                if (Char.IsLetter(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsControl(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsSeparator(e.KeyChar) && cadena[cadena.Length - 1] != ' ')//esta linea no permite el doble de espacios
                {
                   
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception )
            {
                
                //MessageBox.Show("error:" + ex);
            }

        }
        private void txtApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            //carga las variables generales para sustituir valores en caso de ingresar algun dato erroneo
            campoApellido = txtApellido.Text.ToString();
            //variable local para evaluar los espacios
            string cadena = txtApellido.Text.ToString();

            try
            {
                if (Char.IsLetter(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsControl(e.KeyChar))
                {
                    e.Handled = false;
                }
                else if (Char.IsSeparator(e.KeyChar) && cadena[cadena.Length - 1] != ' ')//esta linea no permite el doble de espacios
                {

                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            catch (Exception)
            {

                //MessageBox.Show("error:" + ex);
            }

        }




        private void txtNombre_KeyUp(object sender, KeyEventArgs e)
        {
           
            //elimina los espacios en blanco al inicio del texto
            string cadenaRegularizada = txtNombre.Text.TrimStart(); 
            //elimina espaciado irregular entre palabras
            cadenaRegularizada = Regex.Replace(cadenaRegularizada, @"\s+", " ");
            txtNombre.Text = cadenaRegularizada;
            
           
            if (validacionSoloLetras(txtNombre.Text) == 1)
            {
                txtNombre.Text = campoNombre;
            }
        

           
        }
        private void txtApellido_KeyUp(object sender, KeyEventArgs e)
        {
            //elimina los espacios en blanco al inicio del texto
            string cadenaRegularizada = txtApellido.Text.TrimStart();
            //elimina espaciado irregular entre palabras
            cadenaRegularizada = Regex.Replace(cadenaRegularizada, @"\s+", " ");
            txtApellido.Text = cadenaRegularizada;
            if (validacionSoloLetras(txtApellido.Text) == 1)
            {
                txtApellido.Text = campoApellido;
            }
        
        }
        //esta validacion se realiza por que con ella se asegura no poder PEGAR numeros con ctrl+V
        private int validacionSoloLetras(string texto)
        {
            //esta exprecion regular revisa que no ingrese numeros entre las letras
            bool resultado = Regex.IsMatch(texto, @"^[a-zA-Z ]*$");
            if (!resultado)
            {
                //No es una letra del alfabeto, por lo tanto emitir mensaje de error.
                MessageBox.Show("¡Solo es posible agregar letras!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            return 0;
        }



        //BOTONES DEL FORM

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            if (validaciones() == 0)
            {
                empleados = new empleadosController();
                // Create an ArrayList and add 3 elements.
                ArrayList campos = new ArrayList();
                campos.Add("Nombre");
                campos.Add("Apellido");
                campos.Add("Edad");
                campos.Add("Puesto");
                campos.Add("Fecha");


                ArrayList valores = new ArrayList();
                valores.Add(txtNombre.Text.Trim());
                valores.Add(txtApellido.Text.Trim());
                valores.Add(Int32.Parse(txtEdad.Text));
                valores.Add(cbPuesto.SelectedValue);
                valores.Add(dateFecha.Text);

                empleados.guardar("sp_AltaEmpleado", campos, valores);
                MessageBox.Show("registro exitoso");
                Main ventana1 = Owner as Main;// LA OTRA PARTE DE LA TRANSFERENCIA DE DATOS DE EL FORM ALTA A MAIN 
                ventana1.llenadoGrid(); // LLENA DESPUES DE LA ALTA EL GRID PARA ACTUALIZARLO
                this.Close();
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }


        
   



   


    }
}
