﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PracticaEscritorio.Model.ConfiguracionesBD;



namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class FabricaAdaptadorSMBD
    {
        private Configuracion m_Configuracion;
       // private IAdaptadorSMBD IAdaptador;

        public FabricaAdaptadorSMBD()
        {

        }

        public virtual void Dispose()
        {

        }

        public Configuracion Configuracion
        {
            get
            {
                return m_Configuracion;
            }
            set
            {
                m_Configuracion = value;
            }
        }

        public static IAdaptadorSMBD getAdaptadorSMBD()
        {
            //Este metodo pemitira a la fabrica
            //retornar un manejador segun la
            //configuracion del archivo configuracion.
            //xml, en el cual se especificara la
            //direccion ip, el usuario, y paswword
            //ademas del nombre de la base de datos.


            String IP = Configuracion.getIP();
            String BD = Configuracion.getBD();
            String SMBD = Configuracion.getSMBD();
            String PASS = Configuracion.getPassword();
            String USER = Configuracion.getUsuario();
            IAdaptadorSMBD IAdaptador = null;
            switch (SMBD)
            {

                case "SQLServer":
                    IAdaptador = new AdaptadorSQLServer(IP, BD, USER, PASS);
                    //IAdaptador = new AdaptadorSQLServer();
                    break;
            }
            return IAdaptador;
        }


    }
}
