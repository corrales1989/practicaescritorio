﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using PracticaEscritorio.Model.ConfiguracionesBD;
using System.Windows.Forms;
using System.Collections;


namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class Conexion
    {



        private IAdaptadorSMBD AdaptadorSMBD;
        private FabricaAdaptadorSMBD m_FabricaAdaptadorSMBD;

        public Conexion()
        {
            AdaptadorSMBD = FabricaAdaptadorSMBD.getAdaptadorSMBD();
            //if (AdaptadorSMBD!=null)
            //{
            //    //MessageBox.Show("adaptador creado");
            //}
        }

        public virtual void Dispose() { }

        private void Abrir()
        {

        }


        private int Cerrar()
        {
            return 0;
        }


        /// 
        /// <param name="SQL"></param>
        public DataSet Ejecutar(string SQL)
        {
            return AdaptadorSMBD.Ejecutar(SQL);
        }
        public DataSet EjecutarSP_parametrizado(string nombresp, ArrayList campos, ArrayList valores)
        {
            return AdaptadorSMBD.EjecutarSP_parametrizado(nombresp, campos, valores);
        }
        public DataSet Ejecutar_SP(string nombresp)
        {
            return AdaptadorSMBD.Ejecutar_SP(nombresp);
        }



        public FabricaAdaptadorSMBD FabricaAdaptadorSMBD
        {
            get
            {
                return m_FabricaAdaptadorSMBD;
            }
            set
            {
                m_FabricaAdaptadorSMBD = value;
            }
        }

    }
}
