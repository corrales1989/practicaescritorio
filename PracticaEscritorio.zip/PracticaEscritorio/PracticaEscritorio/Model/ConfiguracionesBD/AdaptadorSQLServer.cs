﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using PracticaEscritorio.Model.ConfiguracionesBD;

namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class AdaptadorSQLServer : IAdaptadorSMBD
    {

        private SqlConnection conexion;
        private string cadenaConexion;
        public AdaptadorSQLServer(string ip, string datos, string usuario, string password)
        {
            cadenaConexion = "server ="+ ip+"; database ="+datos+"; uid = "+usuario+"; pwd ="+password;
            //cadenaConexion = "Data Source=.;Initial Catalog=ProyectoCobranza;Integrated Security=True";
            // cadenaConexion = "Data Source = " + ip + "; Initial Catalog = " + datos + "; User ID = " + usuario + ", contraseña = " + password;
            conexion = new SqlConnection(cadenaConexion);
        }

        public int Abrir()
        {
            conexion.Open();
            return 0;
        }
        public int Cerrar()
        {
            conexion.Close();
            return 0;
        }
        //solo se utiliza con las sentencias sql insert,delete y update
        public DataSet Ejecutar(String SQL)
        {
            this.Abrir();
            //MessageBox.Show(SQL);
            SqlCommand Comando = conexion.CreateCommand();
            Comando.CommandType = CommandType.Text;
            Comando.CommandText = SQL;  //consulta sql
            //Comando.ExecuteNonQuery();
            //MySqlDataReader Datos = Comando.ExecuteReader();            
            SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
            DataSet Datos = new DataSet();
            Adaptador.Fill(Datos);
            this.Cerrar();
            return Datos;
        }
        public DataSet EjecutarSP_parametrizado(string nombresp, ArrayList campos, ArrayList valores)
        {
            ////instrucciones
            //SqlCommand instruccion = new SqlCommand();
            //this.Abrir();
            ////instruccion.Connection = conexion; //asignar la conexion a la instruccion sql
            //instruccion.CommandType = CommandType.StoredProcedure;//procedimiento de almacenado
            //instruccion.CommandText = SQL;//nombre del sp 
            ////asignar los parametros
            ////instruccion.Parameters.Add(new SqlParameter("@id", ppaciente.id));
            //SqlDataAdapter Adaptador = new SqlDataAdapter(instruccion);
            //DataSet Datos = new DataSet();
            //Adaptador.Fill(Datos);
            //this.Cerrar();
            //return Datos;
          //  int valor = 0;
 
            this.Abrir();//abrir conexion 
            SqlCommand Comando = conexion.CreateCommand();//instancia el comando 
            Comando.CommandType = CommandType.StoredProcedure;
            Comando.CommandText = nombresp;  //consulta sql  
            if (valores.Count != 0)
            {
                for (int i = 0; i < campos.Count; i++)
                {
                    
                    Comando.Parameters.Add(new SqlParameter(campos[i].ToString(), valores[i].ToString()));

                }
            }
            SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
            DataSet Datos = new DataSet();
            Adaptador.Fill(Datos);
            this.Cerrar();
            return Datos;

        }
        public DataSet Ejecutar_SP(string nombresp)
        {
            this.Abrir();
            //MessageBox.Show(SQL);
            SqlCommand Comando = conexion.CreateCommand();
            Comando.CommandType = CommandType.StoredProcedure;
            Comando.CommandText = nombresp;  //consulta sql
            //Comando.ExecuteNonQuery();
            //MySqlDataReader Datos = Comando.ExecuteReader();            
            SqlDataAdapter Adaptador = new SqlDataAdapter(Comando);
            DataSet Datos = new DataSet();
            Adaptador.Fill(Datos);
            this.Cerrar();
            return Datos;
        }
    }//end AdaptadorMySQL

}
