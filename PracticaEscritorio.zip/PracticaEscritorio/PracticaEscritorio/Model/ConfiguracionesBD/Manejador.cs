﻿using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PracticaEscritorio.Model.ConfiguracionesBD;



namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class Manejador
    {
        private Conexion Conexion_SMBD;

        public Manejador()
        {
            Conexion_SMBD = new Conexion();
        }

        ~Manejador() { }

        public virtual void Dispose() { }

        /// 
        /// <param name="Tabla"></param>
        /// <param name="Campos"></param>
        /// <param name="Valores"></param>
        /// <param name="Condicion"></param>
        public int Alta(string Tabla, string Campos, string Valores)
        {
            string SQL = "INSERT INTO " + Tabla + " ( " + Campos + ") VALUES ( " + Valores + " )";
            Conexion_SMBD.Ejecutar(SQL);
            return 0;
        }

        /// 
        /// <param name="Tabla"></param>
        /// <param name="Campos"></param>
        /// <param name="Valores"></param>
        /// <param name="Condicion"></param>
        public int Baja(string Tabla, string Condicion)
        {
            string SQL = "DELETE FROM " + Tabla + " WHERE " + Condicion;
            Conexion_SMBD.Ejecutar(SQL);

            return 0;
        }
        /// 
        /// <param name="Tabla"></param>
        /// <param name="Campos"></param>
        /// <param name="Valores"></param>
        /// <param name="Condicion"></param>
        public DataSet Consulta(string Tabla, string Campos, string Condicion)
        {
            if (Campos == "")
            {
                Campos = "*";
            }
            string SQL = "SELECT " + Campos + " FROM " + Tabla;
            if (Condicion != "")
            {
                SQL += " WHERE " + Condicion;
            }
            return Conexion_SMBD.Ejecutar(SQL);

        }
        /// 
        /// <param name="Tabla"></param>
        /// <param name="Campos"></param>
        /// <param name="Valores"></param>
        /// <param name="Condicion"></param>
        public int Modificacion(string Tabla, string CamposValores, string Condicion)
        {
            string SQL = "UPDATE " + Tabla + " SET " + CamposValores + " WHERE " + Condicion;
            Conexion_SMBD.Ejecutar(SQL);
            return 0;
        }

        /// 
        /// <param name="Tabla"></param>
        /// <param name="Campos"></param>
        /// <param name="Valores"></param>
        /// <param name="Condicion"></param>

        public DataSet EjecutarSP_parametrizado(string nombresp, ArrayList campos, ArrayList valores)
        {
            return Conexion_SMBD.EjecutarSP_parametrizado(nombresp, campos, valores);
        }
        public DataSet Ejecutar_SP(string nombresp)
        {
            return Conexion_SMBD.Ejecutar_SP(nombresp);
        }

        public int Reporte(string Tabla, string Campos, string Valores, string Condicion)
        {

            return 0;
        }


    }
}
