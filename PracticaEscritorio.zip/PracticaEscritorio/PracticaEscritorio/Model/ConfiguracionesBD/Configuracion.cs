﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class Configuracion
    {

        //	private Manejador_XML m_Manejador_XML;
        public Configuracion()
        {

        }
        public virtual void Dispose()
        {
        }
        public static string getBD()
        {
            return "Comprasropa";
        }

        public static string getIP()
        {
            return "10.28.114.15";
        }

        public static string getPassword()
        {
            return "1801315ba9e94d79e17603e2c764b070";
        }
        public static string getSMBD()
        {
            return "SQLServer";
        }

        public static string getUsuario()
        {
            return "sysprogsropa";
        }


    }
}
