﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Data;
using System.Text;
using PracticaEscritorio.Model.ConfiguracionesBD;



namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    class AdaptadorDatos
    {



        private Manejador Manejador_SMBD;

        public AdaptadorDatos()
        {

            Manejador_SMBD = new Manejador();
        }

        ~AdaptadorDatos()
        {

        }

        public virtual void Dispose()
        {

        }

        public int Actualizar(string tabla, string camposvalores, string condicion)
        {

            Manejador_SMBD.Modificacion(tabla, camposvalores, condicion);
            return 0;
        }

        public int Eliminar(string tabla, string condicion)
        {
            Manejador_SMBD.Baja(tabla, condicion);
            return 0;
        }

        public int Insertar(string tabla, string campos, string condicion)
        {
            Manejador_SMBD.Alta(tabla, campos, condicion);
            return 0;
        }


        public DataSet Seleccionar(string tabla, string campos, string condicion)
        {
            return Manejador_SMBD.Consulta(tabla, campos, condicion);
        }
        public DataSet Seleccionar_SP_parametrizado(string nombre_SP, ArrayList campos, ArrayList valores)
        {
            return Manejador_SMBD.EjecutarSP_parametrizado(nombre_SP, campos, valores);
        }
        public DataSet Seleccionar_SP(string nombre_SP)
        {
            return Manejador_SMBD.Ejecutar_SP(nombre_SP);
        }
        

    }
}
