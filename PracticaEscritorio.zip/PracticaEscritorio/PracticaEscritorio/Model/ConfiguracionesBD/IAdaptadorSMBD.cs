﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using PracticaEscritorio.Model.ConfiguracionesBD;
using System.Collections;


namespace PracticaEscritorio.Model.ConfiguracionesBD
{
    public interface IAdaptadorSMBD
    {
        int Abrir();
        int Cerrar();
        DataSet Ejecutar(string SQL);
        DataSet EjecutarSP_parametrizado(string nombresp, ArrayList campos, ArrayList valores);
        DataSet Ejecutar_SP(string nombresp);

    }//end IAdaptadorSMBD

}
