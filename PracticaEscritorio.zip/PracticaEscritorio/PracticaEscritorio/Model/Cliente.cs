﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BodegaFuncionesGenerales;
using System.Data;
using PracticaEscritorio.Model.ConfiguracionesBD;


namespace PracticaEscritorio.Model
{
    class Cliente
    {
       
        
    }
}