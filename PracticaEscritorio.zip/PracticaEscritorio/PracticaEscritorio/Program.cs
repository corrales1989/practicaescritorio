﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using BodegaFuncionesGenerales;

namespace PracticaEscritorio
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            General.Conexion.Servidor = "10.28.114.15";
            General.Conexion.Usuario = "sysprogsropa";
            General.Conexion.Password = "1801315ba9e94d79e17603e2c764b070";
            General.Conexion.TipoServer = TipoServer.SqlServer;
            General.Conexion.BaseDeDatos = "COMPRASROPA";

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new PracticaEscritorio.View.Main());

            //Application.Run(new Form1());
        }
    }
}
